﻿using System;
using System.Text;

namespace Discuz.Aggregation
{
    /// <summary>
    /// 聚合缓存策略类
    /// </summary>
    //public class AggregationCacheStrategy : Discuz.Forum.ForumCacheStrategy
    //{
    //    /// <summary>
    //    /// // 默认缓存存活期为5分钟
    //    /// </summary>
    //    private int _timeOut = 5; 

    //    /// <summary>
    //    /// 设置到期相对时间[单位:分钟]
    //    /// </summary>
    //    override public int TimeOut
    //    {
    //        set { _timeOut = (value > 0 && value < 9999) ? value : 5; }
    //        get { return (_timeOut > 0 && _timeOut < 9999) ? _timeOut : 5; }
    //    }
    //}
}
