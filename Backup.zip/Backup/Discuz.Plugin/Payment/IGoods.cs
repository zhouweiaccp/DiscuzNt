﻿
namespace Discuz.Plugin.Payment
{
    /// <summary>
    /// 商品接口
    /// </summary>
    public interface ITrade
    {
    }
}
