using System;

namespace Discuz.Entity
{
	public enum UserPrefDataType
	{
		StringType,
		EnumType,
		HiddenType,
		BoolType,
		ListType,
		LoactionType
	}
}
