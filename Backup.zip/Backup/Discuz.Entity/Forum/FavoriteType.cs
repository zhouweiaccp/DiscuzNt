using System;
using System.Text;

namespace Discuz.Entity
{
    /// <summary>
    /// �ղ�����
    /// </summary>
    public enum FavoriteType
    {
        /// <summary>
        /// ��̳����
        /// </summary>
        ForumTopic = 0,
        /// <summary>
        /// ���
        /// </summary>
        Album = 1,
        /// <summary>
        /// ���˿ռ���־
        /// </summary>
        SpacePost = 2,
        /// <summary>
        /// ��Ʒ
        /// </summary>
        Goods = 3,
    }
}
